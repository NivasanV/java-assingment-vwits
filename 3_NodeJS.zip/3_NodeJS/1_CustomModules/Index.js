
const result = require('./Add')
console.log(result(10,10))