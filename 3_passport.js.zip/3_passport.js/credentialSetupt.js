const GoogleStrategy = require('passport-google-oauth20').Strategy
const passport = require('passport');

const client_Id = "937145707107-rf1hjrqqjlrieiehnmqrtfs1tcqh6p2v.apps.googleusercontent.com"
const client_Secret = "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"

passport.use(new GoogleStrategy({ // npm i passport-google-oauth20
    clientID: client_Id,
    clientSecret: client_Secret,
    callbackURL: "/auth/google/callback"
},
    function (accessToken, refereshTocke, profile, done) {
        console.log('In verify')
        done(null, profile)
    }
))

passport.serializeUser((user, done) => {
    done(null, user)
})

passport.deserializeUser((user, done) => {
    done(null, user)
})